from __future__ import print_function

import boto3
import os
import json
import datetime
import psycopg2
from psycopg2 import Error

print('Loading function')


def handler(event, context):
    # print("Received event: ", event)
    # records = event['Records']
    # print("Records ======== ", event['Records'])
    # firstObj = records[0]
    # bodyObj = firstObj['body']
    # print("Body =============", firstObj['body'])
    # bodyStr = json.loads(bodyObj)
    # buyers = bodyStr['buyers']
    # print("buyers =============", buyers)

    # try:
    # Connect to an existing database
    conn = psycopg2.connect(user=os.environ['DB_USER'],
                            password=os.environ['DB_PWD'],
                            host=os.environ['DB_HOST'],
                            port="5432",
                            database=os.environ['DB_NAME'])

    cursor = conn.cursor()
    sellBillInfoQuery = "INSERT INTO public.sell_bill_info(	buyer_id, gross_total, bill_status, ca_id)" \
                        "VALUES (%s, %s, %s, %s) RETURNING bill_id;";
    sellLinItemsQuery = "INSERT INTO public.sell_bill_items(farmer_id, crop_id, qty_unit, qty, weight, rate, total," \
                        " sell_bill_info_id) VALUES((select farmer_id from lot_stage where date = current_date" \
                        " AND lot_id = %s AND ca_id = %s), %s, %s ,%s, %s, %s, %s, %s) RETURNING farmer_id;"

    buyBillInfoQuery = "INSERT INTO public.buy_bill_info(ca_id, farmer_id, bill_status, lot_id, gross_total) " \
                       "VALUES (%s, %s, 'PENDING', %s, %s) " \
                       "ON CONFLICT (ca_id, farmer_id, bill_date, lot_id) " \
                       "DO UPDATE SET bill_status = 'PENDING', " \
                       "gross_total = (%s + (SELECT gross_total FROM buy_bill_info " \
                       "WHERE ca_id = %s AND farmer_id = %s AND bill_date = CURRENT_DATE AND lot_id = %s)) " \
                       "RETURNING bill_id;"

    buyLineItemsQuery = "INSERT INTO public.buy_bill_items(" \
                        "buyer_id, crop_id, qty_unit, qty, weight, rate, total, buy_bill_info_id)" \
                        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"
    clearQrcode = "UPDATE public.farmer_lot_stage SET is_auctioned = true " \
                  "WHERE qr_code =%s AND lot_stage_id = (SELECT id FROM public.lot_stage " \
                  "WHERE ca_id = %s AND lot_id = %s AND date = CURRENT_DATE);"
    clearBags = "UPDATE public.bag  SET status = 0 " \
                "WHERE date = CURRENT_DATE AND qr_code =%s ;"

    # print("Event object", event)
    records = event['Records']
    # print("records ===============================================", records)
    for i in records:
        bodyStr = i['body']
        res = json.loads(bodyStr)
        buyers = res["buyers"]
        for itr in buyers:
            print("buyer", itr)
            grossTotal = 0
            if itr['weight'] > 0:
                grossTotal = itr['weight'] * itr['rate']
            else:
                grossTotal = itr['qty'] * itr['rate']

            cursor.execute(sellBillInfoQuery, (itr['buyerId'], grossTotal, 'PENDING', res['caId']));
            sellBillId = cursor.fetchone()[0]
            print('Sell bill info id', sellBillId)

            cursor.execute(sellLinItemsQuery, (res['lotId'], res['caId'], res['cropId'],
                                               res['qtyUnit'], itr['qty'], itr['weight'],
                                               itr['rate'], grossTotal, sellBillId));

            famrerId = cursor.fetchone()[0]
            print('famrer id', famrerId)

            cursor.execute(buyBillInfoQuery, (res['caId'], famrerId, res['lotId'], grossTotal,
                                              grossTotal, res['caId'], famrerId, res['lotId']))

            buyBillId = cursor.fetchone()[0]
            print('buuy bill id', buyBillId)

            cursor.execute(buyLineItemsQuery, (itr['buyerId'], res['cropId'], res['qtyUnit'], itr['qty'],
                                               itr['weight'], itr['rate'], grossTotal, buyBillId))

        cursor.execute(clearQrcode, (res['qrCode'], res['caId'], res['lotId']))
        cursor.execute(clearBags, [res['qrCode']])
    conn.commit()
    print("After query execution")
    # Fetch result
    # record = cursor.fetchall()
    # cursor.close()
    conn.close()
    return 0
# except (Exception, Error) as error:
#     print("Error while connecting to PostgreSQL", error)
# finally:
#     if (conn):
#         cursor.close()
#         conn.close()
#         print("PostgreSQL connection is closed")



