from __future__ import print_function

import boto3
import json
import datetime
import os
import psycopg2
from psycopg2 import Error

print('Loading function')


def handler(event, context):
    # print("Received event: ", event)
    # records = event['Records']
    # print("Records ======== ", event['Records'])
    # firstObj = records[0]
    # bodyObj = firstObj['body']
    # print("Body =============", firstObj['body'])
    # bodyStr = json.loads(bodyObj)
    # buyers = bodyStr['buyers']
    # print("buyers =============", buyers)

    # try:
    # Connect to an existing database
    conn = psycopg2.connect(user=os.environ['DB_USER'],
                            password=os.environ['DB_PWD'],
                            host=os.environ['DB_HOST'],
                            port="5432",
                            database=os.environ['DB_NAME'])

    cursor = conn.cursor()
    auditQuery = "INSERT INTO public.bill_audit( " \
                 "bill_id, bill_type, attribute, old_value, new_value, line_item_id, update_by, upddated_on) " \
                 "VALUES (%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata');"

    sellLinItemsQuery = "INSERT INTO public.sell_bill_items(farmer_id, crop_id, qty_unit, qty, weight, rate, total," \
                        " sell_bill_info_id) VALUES((select farmer_id from lot_stage where date = " \
                        "(select (CURRENT_TIMESTAMP + interval '5 hours 30 minutes')::timestamp::date)" \
                        " AND lot_id = %s AND ca_id = %s), %s, %s ,%s, %s, %s, %s, %s) RETURNING farmer_id;"

    buyBillInfoQuery = "INSERT INTO public.buy_bill_info(ca_id, farmer_id, bill_status, lot_id, gross_total, bill_date) " \
                       "VALUES (%s, %s, 'PENDING', %s, %s, (select (CURRENT_TIMESTAMP + interval '5 hours 30 minutes')::timestamp::date)) " \
                       "ON CONFLICT (ca_id, farmer_id, bill_date, lot_id) " \
                       "DO UPDATE SET bill_status = 'PENDING', " \
                       "gross_total = (%s + (SELECT gross_total FROM buy_bill_info " \
                       "WHERE ca_id = %s AND farmer_id = %s AND bill_date = " \
                       "(select (CURRENT_TIMESTAMP + interval '5 hours 30 minutes')::timestamp::date) AND lot_id = %s)) " \
                       "RETURNING bill_id;"

    buyLineItemsQuery = "INSERT INTO public.buy_bill_items(" \
                        "buyer_id, crop_id, qty_unit, qty, weight, rate, total, buy_bill_info_id)" \
                        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"
    clearQrcode = "UPDATE public.farmer_lot_stage SET is_auctioned = true " \
                  "WHERE qr_code =%s AND lot_stage_id = (SELECT id FROM public.lot_stage " \
                  "WHERE ca_id = %s AND lot_id = %s AND date = " \
                  "(select (CURRENT_TIMESTAMP + interval '5 hours 30 minutes')::timestamp::date));"
    clearBags = "UPDATE public.bag  SET status = 0 " \
                "WHERE date = (select (CURRENT_TIMESTAMP + interval '5 hours 30 minutes')::timestamp::date) AND qr_code =%s ;"

    records = event['Records']
    # print("records ===============================================", records)
    for i in records:
        bodyStr = i['body']
        res = json.loads(bodyStr)
        # print("res ===============================================", res)
        newBill = res["newBill"]
        oldBill = res["oldBill"]
        print("oldBill ===============================================", oldBill)
        print("newBill ===============================================", newBill)

        if newBill['action'] == 'CANCEL':
            cursor.execute(auditQuery, (newBill['billId'], newBill['billType'], 'bill_status', oldBill['billStatus'],
                                        newBill['action'], 0, newBill['caId']));

        # bill_id, bill_type, attribute, old_value, new_value, line_item_id, update_by
        rowList = []
        if newBill['action'] == 'UPDATE':
            newBillAttributes = newBill['billAttributes'];
            d1 = oldBill['billDate']
            d11 = str(d1['year']) + '-' + str(d1['month']) + '-' + str(d1['day'])
            d2 = newBillAttributes['billDate']
            d22 = str(d2['year']) + '-' + str(d2['month']) + '-' + str(d2['day'])

            if newBillAttributes['billDate'] != oldBill['billDate']:
                rowList.append((newBill['billId'], newBill['billType'], 'Bill Date',
                                d11, d22, 0, newBill['caId']))

            if newBillAttributes['partyId'] != oldBill['partyId']:
                rowList.append((newBill['billId'], newBill['billType'], 'Party',
                                oldBill['partyId'], newBillAttributes['partyId'], 0, newBill['caId']))

            if newBillAttributes['cashRcvd'] != oldBill['cashRcvd']:
                rowList.append((newBill['billId'], newBill['billType'], 'Cash Recvd/Paid',
                                oldBill['cashRcvd'], newBillAttributes['cashRcvd'], 0, newBill['caId']))

            if newBillAttributes['comm'] != oldBill['comm']:
                rowList.append((newBill['billId'], newBill['billType'], 'comm',
                                oldBill['comm'], newBillAttributes['comm'], 0, newBill['caId']))

            if newBillAttributes['rtComm'] != oldBill['rtComm']:
                rowList.append((newBill['billId'], newBill['billType'], 'Return Comm',
                                oldBill['rtComm'], newBillAttributes['rtComm'], 0, newBill['caId']))

            if newBillAttributes['govtLevies'] != oldBill['govtLevies']:
                rowList.append((newBill['billId'], newBill['billType'], 'Govt Levies',
                                oldBill['govtLevies'], newBillAttributes['govtLevies'], 0, newBill['caId']))

            if newBillAttributes['grossTotal'] != oldBill['grossTotal']:
                rowList.append((newBill['billId'], newBill['billType'], 'Gross Total',
                                oldBill['grossTotal'], newBillAttributes['grossTotal'], 0, newBill['caId']))

            if newBillAttributes['labourCharges'] != oldBill['labourCharges']:
                rowList.append((newBill['billId'], newBill['billType'], 'Labour Charges',
                                oldBill['labourCharges'], newBillAttributes['labourCharges'], 0, newBill['caId']))

            if newBillAttributes['mandiFee'] != oldBill['mandiFee']:
                rowList.append((newBill['billId'], newBill['billType'], 'Mandi Fee',
                                oldBill['mandiFee'], newBillAttributes['mandiFee'], 0, newBill['caId']))

            if newBillAttributes['otherFee'] != oldBill['otherFee']:
                rowList.append((newBill['billId'], newBill['billType'], 'Other Fee',
                                oldBill['otherFee'], newBillAttributes['otherFee'], 0, newBill['caId']))

            if newBillAttributes['outStBal'] != oldBill['outStBal']:
                rowList.append((newBill['billId'], newBill['billType'], 'Out Standing Balance',
                                oldBill['outStBal'], newBillAttributes['outStBal'], 0, newBill['caId']))

            if newBillAttributes['rent'] != oldBill['rent']:
                rowList.append((newBill['billId'], newBill['billType'], 'Rent',
                                oldBill['rent'], newBillAttributes['rent'], 0, newBill['caId']))

            if newBillAttributes['totalPayRecieevable'] != oldBill['totalPayReceivable']:
                rowList.append((newBill['billId'], newBill['billType'], 'Total Pay/Receivable',
                                oldBill['totalPayReceivable'], newBillAttributes['totalPayRecieevable'], 0,
                                newBill['caId']))

            if newBillAttributes['transportation'] != oldBill['transportation']:
                rowList.append((newBill['billId'], newBill['billType'], 'Transportation',
                                oldBill['transportation'], newBillAttributes['transportation'], 0, newBill['caId']))

            if newBillAttributes['transporterId'] != oldBill['transporterId']:
                rowList.append((newBill['billId'], newBill['billType'], 'transporterId',
                                oldBill['transporterId'], newBillAttributes['transporterId'], 0, newBill['caId']))

            if newBill['billType'] == 'BUY':
                if newBillAttributes['advance'] != oldBill['advance']:
                    rowList.append((newBill['billId'], newBill['billType'], 'Advance',
                                    oldBill['advance'], newBillAttributes['advance'], 0, newBill['caId']))

                if newBillAttributes['misc'] != oldBill['misc']:
                    rowList.append((newBill['billId'], newBill['billType'], 'Misc',
                                    oldBill['misc'], newBillAttributes['misc'], 0, newBill['caId']))

            if newBill['lineItems']:
                oldLineItems = oldBill['lineItems']
                for newItr in newBill['lineItems']:
                    if newItr['status'] == 0:
                        rowList.append((newBill['billId'], newBill['billType'], 'Line Item removed',
                                        None, None, newItr['id'], newBill['caId']))

                    if newItr['status'] == 1:
                        rowList.append((newBill['billId'], newBill['billType'], 'Line Item added',
                                        None, None, None, newBill['caId']))

                    if newItr['status'] == 2:
                        for oldItr in oldLineItems:
                            if oldItr['id'] == newItr['id']:
                                if newItr['cropId'] != oldItr['cropId']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'CropId',
                                                    oldItr['cropId'], newItr['cropId'], newItr['id'], newBill['caId']))

                                if newItr['qty'] != oldItr['qty']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'Qty',
                                                    oldItr['qty'], newItr['qty'], newItr['id'], newBill['caId']))

                                if newItr['qtyUnit'] != oldItr['qtyUnit']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'qtyUnit',
                                                    oldItr['qtyUnit'], newItr['qtyUnit'], newItr['id'],
                                                    newBill['caId']))

                                if newItr['rate'] != oldItr['rate']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'rate',
                                                    oldItr['rate'], newItr['rate'], newItr['id'], newBill['caId']))

                                if newItr['rateType'] != oldItr['rateType']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'rateType',
                                                    oldItr['rateType'], newItr['rateType'], newItr['id'],
                                                    newBill['caId']))

                                if newItr['total'] != oldItr['total']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'total',
                                                    oldItr['total'], newItr['total'], newItr['id'], newBill['caId']))

                                if newItr['wastage'] != oldItr['wastage']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'wastage',
                                                    oldItr['wastage'], newItr['wastage'], newItr['id'],
                                                    newBill['caId']))

                                if newItr['weight'] != oldItr['weight']:
                                    rowList.append((newBill['billId'], newBill['billType'], 'weight',
                                                    oldItr['weight'], newItr['weight'], newItr['id'], newBill['caId']))

            cursor.executemany(auditQuery, rowList);

            #     sellBillId = cursor.fetchone()[0]
        #     print('Sell bill info id', sellBillId)

        #     cursor.execute(sellLinItemsQuery, (res['lotId'], res['caId'], res['cropId'],
        #                                       res['qtyUnit'], itr['qty'], itr['weight'],
        #                                       itr['rate'], grossTotal, sellBillId));

        #     famrerId = cursor.fetchone()[0]
        #     print('famrer id', famrerId)

        #     cursor.execute(buyBillInfoQuery, (res['caId'], famrerId, res['lotId'], grossTotal,
        #                                       grossTotal, res['caId'], famrerId, res['lotId']))

        #     buyBillId = cursor.fetchone()[0]
        #     print('buuy bill id', buyBillId)

        #     cursor.execute(buyLineItemsQuery, (itr['buyerId'], res['cropId'], res['qtyUnit'], itr['qty'],
        #                                       itr['weight'], itr['rate'], grossTotal, buyBillId))

        # cursor.execute(clearQrcode, (res['qrCode'], res['caId'], res['lotId']))
        # cursor.execute(clearBags, [res['qrCode']])
    conn.commit()
    print("After query execution")
    # Fetch result
    # record = cursor.fetchall()
    # cursor.close()
    conn.close()
    return 0
# except (Exception, Error) as error:
#     print("Error while connecting to PostgreSQL", error)
# finally:
#     if (conn):
#         cursor.close()
#         conn.close()
#         print("PostgreSQL connection is closed")
