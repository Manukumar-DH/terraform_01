#!/bin/bash -e

#set -x

if [ $# -ne 1 ]; then
    echo "Usage: $(basename $0) <ENVIRONMENT>"
    echo "Example: ./lambda_package.sh.sh audit|auction|ledger"
    exit
fi


app_name=${1}

