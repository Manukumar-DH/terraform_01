from __future__ import print_function

import boto3
import json
import datetime
import os
import psycopg2
from psycopg2 import Error

print('Loading function')


def handler(event, context):
    # print("Received event: ", event)
    # records = event['Records']
    # print("Records ======== ", event['Records'])
    # firstObj = records[0]
    # bodyObj = firstObj['body']
    # print("Body =============", firstObj['body'])
    # bodyStr = json.loads(bodyObj)
    # buyers = bodyStr['buyers']
    # print("buyers =============", buyers)

    # try:
    # Connect to an existing database
    conn = psycopg2.connect(user=os.environ['DB_USER'],
                            password=os.environ['DB_PWD'],
                            host=os.environ['DB_HOST'],
                            port="5432",
                            database=os.environ['DB_NAME'])

    cursor = conn.cursor()
    ledgerQiuery = "INSERT INTO public.ledger(ca_id, party_id, tobe_paid_rcvd, type) " \
                   "VALUES(%s, %s, %s, %s) " \
                   "ON CONFLICT(ca_id, party_id) DO UPDATE " \
                   "SET date = (select (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::timestamp::date), tobe_paid_rcvd = %s + " \
                   "(SELECT tobe_paid_rcvd FROM public.ledger " \
                   "WHERE ca_id = %s AND party_id = %s) RETURNING tobe_paid_rcvd;"

    partnerLedgerQiuery = "INSERT INTO public.ledger_txn(ca_id, party_id, ref_id, tobe_paid_rcvd, balance) " \
                          "VALUES(%s,%s, %s, %s, %s);"

    recordPayment = "UPDATE public.ledger SET date = (select (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::timestamp::date),  " \
                    "paid_rcvd = (%s + (select paid_rcvd from public.ledger  " \
                    "where ca_id = %s AND party_id =%s)), tobe_paid_rcvd =(select tobe_paid_rcvd from public.ledger  " \
                    "where ca_id = %s AND party_id = %s) - %s where ca_id =%s AND party_id =%s  " \
                    "RETURNING tobe_paid_rcvd;"

    rcordPmtPartnerLedger = "INSERT INTO public.ledger_txn( ca_id, party_id, ref_id, paid_rcvd, balance, created_on)  " \
                            "VALUES (%s, %s, 'P'||nextval('ledger_txn_seq')::TEXT, %s, %s,  " \
                            "CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata' );"



    # print("Event object", event)
    records = event['Records']
    print("records ===============================================", records)
    for i in records:
        bodyStr = i['body']
        res = json.loads(bodyStr)
        cursor.execute(ledgerQiuery, (res['caId'], res['partyId'], res['tobePaidRcvd'],
                                      res['ledgerType'], res['tobePaidRcvd'], res['caId'], res['partyId']));
        balance = cursor.fetchone()[0]
        print('Sell bill info id', balance)

        cursor.execute(partnerLedgerQiuery, (res['caId'], res['partyId'], res['billId'],
                                             res['tobePaidRcvd'], balance));

        if res['cashRcvd'] > 0:
            print("Details ==========================", res['cashRcvd'])
            cursor.execute(recordPayment, (res['cashRcvd'], res['caId'], res['partyId'], res['caId'],
                                           res['partyId'], res['cashRcvd'], res['caId'], res['partyId']))

            balance1 = cursor.fetchone()[0]

            cursor.execute(rcordPmtPartnerLedger, (res['caId'], res['partyId'], res['cashRcvd'], balance1))


    conn.commit()
    print("After query execution")
    # Fetch result
    # record = cursor.fetchall()
    # cursor.close()
    conn.close()
    return 0
# except (Exception, Error) as error:
#     print("Error while connecting to PostgreSQL", error)
# finally:
#     if (conn):
#         cursor.close()
#         conn.close()
#         print("PostgreSQL connection is closed")
